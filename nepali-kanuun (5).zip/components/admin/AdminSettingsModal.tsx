
import React, { useState, useEffect, useRef } from 'react';
import { CloseIcon } from '../../constants';

interface AdminSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentAppIconUrl: string | null;
  onAppIconUrlChange: (newUrl: string | null) => void;
  currentCustomPlayStoreIconUrl: string | null; // New prop
  onCustomPlayStoreIconUrlChange: (newUrl: string | null) => void; // New prop
  onPasswordChange: (currentPass: string, newPass: string) => Promise<boolean>; 
  t: (key: string, params?: Record<string, string | number>) => string;
}

const MAX_IMAGE_SIZE_MB = 2;
const MAX_IMAGE_SIZE_BYTES = MAX_IMAGE_SIZE_MB * 1024 * 1024;
const ALLOWED_IMAGE_TYPES = ['image/png', 'image/jpeg', 'image/gif', 'image/webp'];
const DEFAULT_PLAY_STORE_ICON_PLACEHOLDER = "https://www.citypng.com/public/uploads/preview/hd-google-play-playstore-logo-symbol-png-701751694777134cuw3jc7voo.png"; // Fallback for preview

const AdminSettingsModal: React.FC<AdminSettingsModalProps> = ({
  isOpen,
  onClose,
  currentAppIconUrl,
  onAppIconUrlChange,
  currentCustomPlayStoreIconUrl,
  onCustomPlayStoreIconUrlChange,
  onPasswordChange,
  t,
}) => {
  const [appIconPreviewUrl, setAppIconPreviewUrl] = useState<string | null>(null);
  const [appIconError, setAppIconError] = useState<string>('');
  const appIconFileInputRef = useRef<HTMLInputElement>(null);

  const [playStoreIconPreviewUrl, setPlayStoreIconPreviewUrl] = useState<string | null>(null);
  const [playStoreIconError, setPlayStoreIconError] = useState<string>('');
  const playStoreIconFileInputRef = useRef<HTMLInputElement>(null);

  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [passwordSuccess, setPasswordSuccess] = useState('');

  useEffect(() => {
    if (isOpen) {
      setAppIconPreviewUrl(null);
      setAppIconError('');
      setPlayStoreIconPreviewUrl(null);
      setPlayStoreIconError('');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmNewPassword('');
      setPasswordError('');
      setPasswordSuccess('');
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleImageFileChange = (
    event: React.ChangeEvent<HTMLInputElement>,
    setPreviewUrl: React.Dispatch<React.SetStateAction<string | null>>,
    setErrorState: React.Dispatch<React.SetStateAction<string>>,
    fileInputRefCurrent: HTMLInputElement | null
  ) => {
    const file = event.target.files?.[0];
    setErrorState('');
    setPreviewUrl(null);

    if (file) {
      if (!ALLOWED_IMAGE_TYPES.includes(file.type)) {
        setErrorState(t('imageTypeInvalidError') + ` (${ALLOWED_IMAGE_TYPES.map(t => t.split('/')[1]).join(', ')})`);
        if(fileInputRefCurrent) fileInputRefCurrent.value = "";
        return;
      }
      if (file.size > MAX_IMAGE_SIZE_BYTES) {
        setErrorState(t('imageSizeLimitError', { size: MAX_IMAGE_SIZE_MB }));
        if(fileInputRefCurrent) fileInputRefCurrent.value = "";
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveAppIcon = () => {
    if (appIconPreviewUrl) {
      onAppIconUrlChange(appIconPreviewUrl);
      setAppIconPreviewUrl(null); 
      if(appIconFileInputRef.current) appIconFileInputRef.current.value = "";
    }
  };
  
  const handleRemoveAppIcon = () => {
    onAppIconUrlChange(null);
    setAppIconPreviewUrl(null);
    if(appIconFileInputRef.current) appIconFileInputRef.current.value = "";
  }

  const handleSaveCustomPlayStoreIcon = () => {
    if (playStoreIconPreviewUrl) {
      onCustomPlayStoreIconUrlChange(playStoreIconPreviewUrl);
      setPlayStoreIconPreviewUrl(null);
      if (playStoreIconFileInputRef.current) playStoreIconFileInputRef.current.value = "";
    }
  };

  const handleRemoveCustomPlayStoreIcon = () => {
    onCustomPlayStoreIconUrlChange(null);
    setPlayStoreIconPreviewUrl(null);
    if (playStoreIconFileInputRef.current) playStoreIconFileInputRef.current.value = "";
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError('');
    setPasswordSuccess('');

    if (!currentPassword || !newPassword || !confirmNewPassword) {
      setPasswordError(t('allPasswordFieldsRequired')); 
      return;
    }
    if (newPassword !== confirmNewPassword) {
      setPasswordError(t('passwordsDoNotMatch'));
      return;
    }
    if (newPassword.length < 6) {
      setPasswordError(t('passwordTooShort'));
      return;
    }

    const success = await onPasswordChange(currentPassword, newPassword);
    if (success) {
      setPasswordSuccess(t('passwordChangeSuccess'));
      setCurrentPassword('');
      setNewPassword('');
      setConfirmNewPassword('');
    } else {
      setPasswordError(t('passwordChangeFailed'));
    }
  };
  
  const displayAppIconSrc = appIconPreviewUrl || currentAppIconUrl;
  const displayPlayStoreIconSrc = playStoreIconPreviewUrl || currentCustomPlayStoreIconUrl || DEFAULT_PLAY_STORE_ICON_PLACEHOLDER;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 z-[90] backdrop-blur-sm animate-fadeIn" role="dialog" aria-modal="true" aria-labelledby="admin-settings-title">
      <div className="bg-card-light dark:bg-card-dark p-6 sm:p-8 rounded-lg shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto custom-scrollbar-hidden">
        <div className="flex justify-between items-center mb-6">
          <h2 id="admin-settings-title" className="text-2xl font-bold text-primary-DEFAULT dark:text-primary-dark">{t('adminSettings')}</h2>
          <button
            onClick={onClose}
            className="p-1 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700"
            aria-label={t('closeSettings')}
          >
            <CloseIcon className="w-5 h-5 text-gray-600 dark:text-gray-300" />
          </button>
        </div>

        {/* App Icon Upload Section */}
        <div className="mb-6 pb-6 border-b border-bordercol-light dark:border-bordercol-dark">
          <h3 className="text-lg font-semibold mb-3 text-textcol-light dark:text-textcol-dark">{t('appIconUrlLabel')}</h3>
          <div className="flex flex-col sm:flex-row items-center space-y-3 sm:space-y-0 sm:space-x-4">
            <div className="w-20 h-20 bg-gray-100 dark:bg-gray-700 rounded-md flex items-center justify-center overflow-hidden border border-bordercol-light dark:border-bordercol-dark flex-shrink-0">
              {displayAppIconSrc ? (
                <img src={displayAppIconSrc} alt={t('appIconPreview')} className="object-contain w-full h-full" />
              ) : (
                <span className="text-xs text-gray-500 dark:text-gray-400 px-1 text-center">{t('noIconSet')}</span>
              )}
            </div>
            <div className="flex flex-col space-y-2 w-full sm:w-auto">
              <input 
                type="file" 
                id="app-icon-upload" 
                className="hidden" 
                accept={ALLOWED_IMAGE_TYPES.join(',')} 
                onChange={(e) => handleImageFileChange(e, setAppIconPreviewUrl, setAppIconError, appIconFileInputRef.current)} 
                ref={appIconFileInputRef} 
              />
              <button 
                type="button" 
                onClick={() => appIconFileInputRef.current?.click()} 
                className="w-full sm:w-auto px-4 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-md text-textcol-light dark:text-textcol-dark hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors"
              >
                {currentAppIconUrl || appIconPreviewUrl ? t('changeAppIconButton') : t('uploadAppIconButton')}
              </button>
              {appIconPreviewUrl && (
                <button 
                  onClick={handleSaveAppIcon} 
                  className="w-full sm:w-auto px-4 py-2 text-sm bg-primary-DEFAULT hover:bg-primary-hover text-white font-semibold rounded-md transition-colors"
                >
                  {t('saveIcon')}
                </button>
              )}
              {(currentAppIconUrl && !appIconPreviewUrl) && (
                 <button 
                  onClick={handleRemoveAppIcon} 
                  className="w-full sm:w-auto px-4 py-2 text-sm bg-red-500 hover:bg-red-600 text-white font-semibold rounded-md transition-colors"
                >
                  {t('removeIcon')}
                </button>
              )}
            </div>
          </div>
          {appIconError && <p className="text-xs text-red-500 dark:text-red-400 mt-2">{appIconError}</p>}
        </div>

        {/* Custom Play Store Icon Upload Section */}
        <div className="mb-6 pb-6 border-b border-bordercol-light dark:border-bordercol-dark">
          <h3 className="text-lg font-semibold mb-3 text-textcol-light dark:text-textcol-dark">{t('customPlayStoreIconLabel')}</h3>
          <div className="flex flex-col sm:flex-row items-center space-y-3 sm:space-y-0 sm:space-x-4">
            <div className="w-20 h-20 bg-gray-100 dark:bg-gray-700 rounded-md flex items-center justify-center overflow-hidden border border-bordercol-light dark:border-bordercol-dark flex-shrink-0">
                <img src={displayPlayStoreIconSrc} alt={t('playStoreIconPreview')} className="object-contain w-full h-full" />
            </div>
            <div className="flex flex-col space-y-2 w-full sm:w-auto">
              <input 
                type="file" 
                id="playstore-icon-upload" 
                className="hidden" 
                accept={ALLOWED_IMAGE_TYPES.join(',')} 
                onChange={(e) => handleImageFileChange(e, setPlayStoreIconPreviewUrl, setPlayStoreIconError, playStoreIconFileInputRef.current)}
                ref={playStoreIconFileInputRef} 
              />
              <button 
                type="button" 
                onClick={() => playStoreIconFileInputRef.current?.click()} 
                className="w-full sm:w-auto px-4 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-md text-textcol-light dark:text-textcol-dark hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors"
              >
                {currentCustomPlayStoreIconUrl || playStoreIconPreviewUrl ? t('changePlayStoreIconButton') : t('uploadPlayStoreIconButton')}
              </button>
              {playStoreIconPreviewUrl && (
                <button 
                  onClick={handleSaveCustomPlayStoreIcon} 
                  className="w-full sm:w-auto px-4 py-2 text-sm bg-primary-DEFAULT hover:bg-primary-hover text-white font-semibold rounded-md transition-colors"
                >
                  {t('savePlayStoreIconButton')}
                </button>
              )}
              {(currentCustomPlayStoreIconUrl && !playStoreIconPreviewUrl) && (
                 <button 
                  onClick={handleRemoveCustomPlayStoreIcon} 
                  className="w-full sm:w-auto px-4 py-2 text-sm bg-red-500 hover:bg-red-600 text-white font-semibold rounded-md transition-colors"
                >
                  {t('removePlayStoreIconButton')}
                </button>
              )}
            </div>
          </div>
          {playStoreIconError && <p className="text-xs text-red-500 dark:text-red-400 mt-2">{playStoreIconError}</p>}
           <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">{t('playStoreIconUploadNote')}</p>
        </div>


        {/* Change Password Setting */}
        <div>
          <h3 className="text-lg font-semibold mb-3 text-textcol-light dark:text-textcol-dark">{t('changePasswordLabel')}</h3>
          {passwordError && <p className="text-sm text-red-600 dark:text-red-400 mb-2">{passwordError}</p>}
          {passwordSuccess && <p className="text-sm text-green-600 dark:text-green-400 mb-2">{passwordSuccess}</p>}
          <form onSubmit={handleChangePassword} className="space-y-3">
            <div>
              <label htmlFor="currentPassword" className="block text-sm font-medium text-textcol-light dark:text-textcol-dark">{t('currentPasswordLabel')}</label>
              <input
                type="password"
                id="currentPassword"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                className="w-full p-2 border border-bordercol-light dark:border-bordercol-dark rounded-md bg-background-light dark:bg-gray-700 focus:ring-2 focus:ring-primary-DEFAULT dark:focus:ring-primary-dark"
                required
              />
            </div>
            <div>
              <label htmlFor="newPassword" className="block text-sm font-medium text-textcol-light dark:text-textcol-dark">{t('newPasswordLabel')}</label>
              <input
                type="password"
                id="newPassword"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="w-full p-2 border border-bordercol-light dark:border-bordercol-dark rounded-md bg-background-light dark:bg-gray-700 focus:ring-2 focus:ring-primary-DEFAULT dark:focus:ring-primary-dark"
                required
              />
            </div>
            <div>
              <label htmlFor="confirmNewPassword" className="block text-sm font-medium text-textcol-light dark:text-textcol-dark">{t('confirmNewPasswordLabel')}</label>
              <input
                type="password"
                id="confirmNewPassword"
                value={confirmNewPassword}
                onChange={(e) => setConfirmNewPassword(e.target.value)}
                className="w-full p-2 border border-bordercol-light dark:border-bordercol-dark rounded-md bg-background-light dark:bg-gray-700 focus:ring-2 focus:ring-primary-DEFAULT dark:focus:ring-primary-dark"
                required
              />
            </div>
            <button
              type="submit"
              className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-textcol-light dark:text-textcol-dark hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors font-semibold"
            >
              {t('changePasswordLabel')}
            </button>
          </form>
        </div>

        <div className="mt-8 text-right">
            <button
                onClick={onClose}
                className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-textcol-light dark:text-textcol-dark hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors"
            >
                {t('closeSettings')}
            </button>
        </div>
      </div>
    </div>
  );
};

export default AdminSettingsModal;
