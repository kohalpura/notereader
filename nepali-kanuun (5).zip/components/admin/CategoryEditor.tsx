
import React, { useState, useEffect } from 'react';
import { Category, LocalizedString } from '../../types';
import { CloseIcon } from '../../constants';

interface CategoryEditorProps {
  initialCategory: Category | null;
  onSave: (category: Category) => void;
  onCancel: () => void;
  t: (key: string) => string;
}

const CategoryEditor: React.FC<CategoryEditorProps> = ({ initialCategory, onSave, onCancel, t }) => {
  const [nameEn, setNameEn] = useState('');
  const [nameNe, setNameNe] = useState('');
  const [hasChanges, setHasChanges] = useState(false);

  useEffect(() => {
    if (initialCategory) {
      setNameEn(initialCategory.name.en);
      setNameNe(initialCategory.name.ne || '');
      setHasChanges(false); 
    } else {
      setNameEn('');
      setNameNe('');
      setHasChanges(false);
    }
  }, [initialCategory]);

  const handleNameEnChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setNameEn(e.target.value);
    setHasChanges(true);
  };
  const handleNameNeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setNameNe(e.target.value);
    setHasChanges(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nameEn.trim()) {
      alert(t('categoryNameEmptyAlert')); // English name is mandatory
      return;
    }
    
    if (initialCategory && !hasChanges) {
        return;
    }

    const localizedName: LocalizedString = {
      en: nameEn.trim(),
      ne: nameNe.trim() || undefined, // Store empty string as undefined for ne
    };

    onSave({
      id: initialCategory ? initialCategory.id : '', // ID will be generated/confirmed in App.tsx based on English name
      name: localizedName,
      isDeletable: initialCategory ? initialCategory.isDeletable : true,
    });
  };

  const isCreatingNew = !initialCategory;
  const showSubmitButton = isCreatingNew || (initialCategory && hasChanges);
  const submitButtonText = initialCategory ? t('saveChanges') : t('addNewCategory');
  const submitButtonClasses = "px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-textcol-light dark:text-textcol-dark hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors";
  

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center p-4 z-[70] backdrop-blur-sm animate-fadeIn">
      <form
        onSubmit={handleSubmit}
        className="bg-card-light dark:bg-card-dark p-6 sm:p-8 rounded-lg shadow-2xl w-full max-w-md overflow-y-auto custom-scrollbar-hidden max-h-[90vh]"
        role="dialog"
        aria-modal="true"
        aria-labelledby="category-editor-title"
      >
        <div className="flex justify-between items-center mb-6">
          <h2 id="category-editor-title" className="text-2xl font-bold text-primary-DEFAULT dark:text-primary-dark">
            {initialCategory ? t('editCategory') : t('addNewCategory')}
          </h2>
          <button
            type="button"
            onClick={onCancel}
            className="p-1 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700"
            aria-label={t('closeEditor')} 
          >
            <CloseIcon className="w-5 h-5 text-gray-600 dark:text-gray-300" />
          </button>
        </div>

        <div className="mb-4">
          <label htmlFor="categoryNameEn" className="block text-sm font-medium text-textcol-light dark:text-textcol-dark mb-1">
            {t('categoryNameEnLabel')}<span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            id="categoryNameEn"
            value={nameEn}
            onChange={handleNameEnChange}
            className="w-full p-2.5 border border-bordercol-light dark:border-bordercol-dark rounded-md bg-background-light dark:bg-gray-700 focus:ring-2 focus:ring-primary-DEFAULT dark:focus:ring-primary-dark"
            required
            autoFocus
          />
        </div>
        <div className="mb-4">
          <label htmlFor="categoryNameNe" className="block text-sm font-medium text-textcol-light dark:text-textcol-dark mb-1">
            {t('categoryNameNeLabel')}
          </label>
          <input
            type="text"
            id="categoryNameNe"
            value={nameNe}
            onChange={handleNameNeChange}
            className="w-full p-2.5 border border-bordercol-light dark:border-bordercol-dark rounded-md bg-background-light dark:bg-gray-700 focus:ring-2 focus:ring-primary-DEFAULT dark:focus:ring-primary-dark"
          />
        </div>


        <div className="flex justify-end space-x-3 mt-8">
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-textcol-light dark:text-textcol-dark hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors"
          >
            {t('cancel')}
          </button>
          {showSubmitButton && (
            <button
              type="submit"
              className={submitButtonClasses}
            >
              {submitButtonText}
            </button>
          )}
        </div>
      </form>
    </div>
  );
};

export default CategoryEditor;
