
import React, { useState, useEffect } from 'react';
import { FooterSection, LocalizedString, FooterSectionActionType } from '../../types';
import { CloseIcon } from '../../constants';

interface FooterSectionEditorProps {
  initialSection: FooterSection | null;
  onSave: (section: FooterSection) => void;
  onCancel: () => void;
  t: (key: string) => string;
}

const FooterSectionEditor: React.FC<FooterSectionEditorProps> = ({ initialSection, onSave, onCancel, t }) => {
  const [titleEn, setTitleEn] = useState('');
  const [titleNe, setTitleNe] = useState('');
  const [actionType, setActionType] = useState<FooterSectionActionType>(FooterSectionActionType.LINK);
  const [link, setLink] = useState('');
  const [linkIsPlayStore, setLinkIsPlayStore] = useState(false);
  const [contentEn, setContentEn] = useState('');
  const [contentNe, setContentNe] = useState('');
  const [isVisible, setIsVisible] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (initialSection) {
      setTitleEn(initialSection.title.en);
      setTitleNe(initialSection.title.ne || '');
      setActionType(initialSection.actionType);
      setLink(initialSection.link || '');
      setLinkIsPlayStore(initialSection.linkIsPlayStore || false);
      setContentEn(initialSection.content?.en || '');
      setContentNe(initialSection.content?.ne || '');
      setIsVisible(initialSection.isVisible);
    } else {
      // Defaults for new section
      setTitleEn('');
      setTitleNe('');
      setActionType(FooterSectionActionType.LINK);
      setLink('');
      setLinkIsPlayStore(false);
      setContentEn('');
      setContentNe('');
      setIsVisible(true);
    }
    setError('');
  }, [initialSection]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!titleEn.trim()) {
      setError(t('titleMissing'));
      return;
    }
    if (!actionType) {
        setError(t('actionTypeMissing'));
        return;
    }
    if (actionType === FooterSectionActionType.LINK && !link.trim()) {
        setError(t('linkMissing'));
        return;
    }
    if (actionType === FooterSectionActionType.MODAL_CONTENT && !contentEn.trim()) {
        setError(t('contentMissing'));
        return;
    }


    const sectionData: FooterSection = {
      id: initialSection ? initialSection.id : '', // ID and order handled by App.tsx
      order: initialSection ? initialSection.order : 0,
      title: { en: titleEn.trim(), ne: titleNe.trim() || undefined },
      actionType,
      link: actionType === FooterSectionActionType.LINK ? link.trim() : undefined,
      linkIsPlayStore: actionType === FooterSectionActionType.LINK ? linkIsPlayStore : undefined,
      content: actionType === FooterSectionActionType.MODAL_CONTENT ? { en: contentEn.trim(), ne: contentNe.trim() || undefined } : undefined,
      isVisible,
    };
    onSave(sectionData);
  };
  
  const inputBaseClass = "w-full p-2.5 border border-bordercol-light dark:border-bordercol-dark rounded-md bg-background-light dark:bg-gray-700 focus:ring-2 focus:ring-primary-DEFAULT dark:focus:ring-primary-dark";
  const labelBaseClass = "block text-sm font-medium text-textcol-light dark:text-textcol-dark mb-1";

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center p-4 z-[70] backdrop-blur-sm animate-fadeIn">
      <form
        onSubmit={handleSubmit}
        className="bg-card-light dark:bg-card-dark p-6 sm:p-8 rounded-lg shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto custom-scrollbar-hidden"
        role="dialog"
        aria-modal="true"
        aria-labelledby="footer-section-editor-title"
      >
        <div className="flex justify-between items-center mb-6">
          <h2 id="footer-section-editor-title" className="text-2xl font-bold text-primary-DEFAULT dark:text-primary-dark">
            {initialSection ? t('editFooterSection') : t('addNewFooterSection')}
          </h2>
          <button type="button" onClick={onCancel} className="p-1 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700" aria-label={t('closeEditor')}>
            <CloseIcon className="w-5 h-5 text-gray-600 dark:text-gray-300" />
          </button>
        </div>

        {error && <p className="mb-4 p-3 bg-red-100 dark:bg-red-800 border border-red-300 dark:border-red-700 text-red-600 dark:text-red-200 rounded-md text-sm">{error}</p>}

        <div className="space-y-4">
          <div>
            <label htmlFor="titleEn" className={labelBaseClass}>{t('footerSectionTitleEnLabel')}<span className="text-red-500">*</span></label>
            <input type="text" id="titleEn" value={titleEn} onChange={(e) => setTitleEn(e.target.value)} className={inputBaseClass} required />
          </div>
          <div>
            <label htmlFor="titleNe" className={labelBaseClass}>{t('footerSectionTitleNeLabel')}</label>
            <input type="text" id="titleNe" value={titleNe} onChange={(e) => setTitleNe(e.target.value)} className={inputBaseClass} />
          </div>

          <div>
            <label htmlFor="actionType" className={labelBaseClass}>{t('footerSectionActionTypeLabel')}<span className="text-red-500">*</span></label>
            <select id="actionType" value={actionType} onChange={(e) => setActionType(e.target.value as FooterSectionActionType)} className={inputBaseClass}>
              <option value={FooterSectionActionType.LINK}>{t('footerSectionActionTypeLink')}</option>
              <option value={FooterSectionActionType.MODAL_CONTENT}>{t('footerSectionActionTypeModal')}</option>
            </select>
          </div>

          {actionType === FooterSectionActionType.LINK && (
            <div className="space-y-4 p-3 border border-dashed border-gray-300 dark:border-gray-600 rounded-md">
              <div>
                <label htmlFor="link" className={labelBaseClass}>{t('footerSectionLinkLabel')}<span className="text-red-500">*</span></label>
                <input type="url" id="link" value={link} onChange={(e) => setLink(e.target.value)} placeholder={t('footerSectionLinkPlaceholder')} className={inputBaseClass} />
              </div>
              <div className="flex items-center">
                <input type="checkbox" id="linkIsPlayStore" checked={linkIsPlayStore} onChange={(e) => setLinkIsPlayStore(e.target.checked)} className="form-checkbox h-4 w-4 text-primary-DEFAULT rounded mr-2" />
                <label htmlFor="linkIsPlayStore" className="text-sm text-textcol-light dark:text-textcol-dark">{t('footerSectionLinkIsPlayStoreLabel')}</label>
              </div>
            </div>
          )}

          {actionType === FooterSectionActionType.MODAL_CONTENT && (
            <div className="space-y-4 p-3 border border-dashed border-gray-300 dark:border-gray-600 rounded-md">
              <div>
                <label htmlFor="contentEn" className={labelBaseClass}>{t('footerSectionContentEnLabel')}<span className="text-red-500">*</span></label>
                <textarea id="contentEn" value={contentEn} onChange={(e) => setContentEn(e.target.value)} rows={4} placeholder={t('footerSectionContentPlaceholder')} className={inputBaseClass}></textarea>
              </div>
              <div>
                <label htmlFor="contentNe" className={labelBaseClass}>{t('footerSectionContentNeLabel')}</label>
                <textarea id="contentNe" value={contentNe} onChange={(e) => setContentNe(e.target.value)} rows={4} placeholder={t('footerSectionContentPlaceholder')} className={inputBaseClass}></textarea>
              </div>
            </div>
          )}
          
          <div className="flex items-center pt-2">
            <input type="checkbox" id="isVisible" checked={isVisible} onChange={(e) => setIsVisible(e.target.checked)} className="form-checkbox h-4 w-4 text-primary-DEFAULT rounded mr-2" />
            <label htmlFor="isVisible" className="text-sm text-textcol-light dark:text-textcol-dark">{t('footerSectionVisibilityLabel')}</label>
          </div>
        </div>

        <div className="flex justify-end space-x-3 mt-8">
          <button type="button" onClick={onCancel} className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-textcol-light dark:text-textcol-dark hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors">
            {t('cancel')}
          </button>
          <button type="submit" className="px-4 py-2 bg-primary-DEFAULT hover:bg-primary-hover dark:bg-primary-dark dark:hover:bg-primary-darkhover text-white rounded-md transition-colors">
            {initialSection ? t('saveChanges') : t('add')}
          </button>
        </div>
      </form>
    </div>
  );
};

export default FooterSectionEditor;
