
import React from 'react';
import { Category, Language, LocalizedString } from '../../types';
import { CollectionIcon, EditIcon, DeleteIcon, ChevronRightIcon, getLocalizedText } from '../../constants';

interface CategoryCardProps {
  category: Category;
  noteCount: number;
  onClick: () => void;
  onEdit: () => void;
  onDelete: () => void;
  t: (key: string, params?: Record<string, string | number>) => string;
  currentLanguage: Language;
}

const CategoryCard: React.FC<CategoryCardProps> = ({ category, noteCount, onClick, onEdit, onDelete, t, currentLanguage }) => {
  const isUncategorized = category.id === 'uncategorized';
  const localizedCategoryName = getLocalizedText(category.name, currentLanguage);

  const handleEditClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (category.isDeletable === false || isUncategorized) { 
      alert(t('cannotEditUncategorized')); 
      return;
    }
    onEdit();
  };

  const handleDeleteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
     if (category.isDeletable === false || isUncategorized) {
      alert(t('cannotDeleteUncategorized')); 
      return;
    }
    onDelete();
  };


  return (
    <div
      className="bg-card-light dark:bg-card-dark shadow-lg rounded-lg p-4 hover:shadow-xl transition-shadow duration-300 flex flex-col justify-between"
    >
      <div className="flex-grow cursor-pointer" onClick={onClick}>
        <div className="flex items-center mb-3">
          <CollectionIcon className="w-8 h-8 text-primary-DEFAULT dark:text-primary-dark mr-3" />
          <h3 className="text-xl font-semibold text-textcol-light dark:text-textcol-dark truncate" title={localizedCategoryName}>
            {localizedCategoryName}
          </h3>
        </div>
        <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
          {noteCount} {noteCount === 1 ? t('noteSingular') : t('notesPlural')}
        </p>
      </div>
      <div className="flex justify-between items-center border-t border-bordercol-light dark:border-bordercol-dark pt-3 mt-auto">
         <button
          onClick={onClick}
          className="text-sm text-primary-DEFAULT dark:text-primary-dark hover:underline flex items-center"
          aria-label={`${t('viewNotesInCategory')} ${localizedCategoryName}`}
        >
          {t('viewNotes')} <ChevronRightIcon className="w-4 h-4 ml-1" />
        </button>
        {(category.isDeletable !== false && !isUncategorized) && (
          <div className="flex space-x-2">
            <button
              onClick={handleEditClick}
              className="p-1.5 text-blue-500 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300 rounded-full hover:bg-blue-100 dark:hover:bg-blue-900"
              aria-label={`${t('editCategory')} ${localizedCategoryName}`}
            >
              <EditIcon className="w-4 h-4" />
            </button>
            <button
              onClick={handleDeleteClick}
              className="p-1.5 text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300 rounded-full hover:bg-red-100 dark:hover:bg-red-900"
              aria-label={`${t('deleteCategory')} ${localizedCategoryName}`}
            >
              <DeleteIcon className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default CategoryCard;