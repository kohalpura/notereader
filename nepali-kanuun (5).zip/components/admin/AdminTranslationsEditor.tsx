
import React, { useState, useEffect, useMemo } from 'react';
import { AllTranslations, Translations } from '../../types';
import { ArrowLeftIcon, SearchIcon } from '../../constants';

interface AdminTranslationsEditorProps {
  currentCustomTranslations: AllTranslations;
  defaultTranslations: AllTranslations; // This is translationsData from translations.ts
  onSaveTranslations: (updatedTranslations: AllTranslations) => void;
  onResetAllToDefaults: () => void;
  t: (key: string, params?: Record<string, string | number>) => string;
  onBack: () => void;
}

const AdminTranslationsEditor: React.FC<AdminTranslationsEditorProps> = ({
  currentCustomTranslations,
  defaultTranslations,
  onSaveTranslations,
  onResetAllToDefaults,
  t,
  onBack,
}) => {
  const [editedTranslations, setEditedTranslations] = useState<AllTranslations>(JSON.parse(JSON.stringify(currentCustomTranslations)));
  const [searchTerm, setSearchTerm] = useState('');
  const [feedbackMessage, setFeedbackMessage] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  useEffect(() => {
    // Deep copy to avoid direct mutation
    setEditedTranslations(JSON.parse(JSON.stringify(currentCustomTranslations)));
  }, [currentCustomTranslations]);

  const handleInputChange = (lang: 'en' | 'ne', key: string, value: string) => {
    setEditedTranslations(prev => {
      const newTranslations = JSON.parse(JSON.stringify(prev)); // Deep copy
      if (!newTranslations[lang]) {
        newTranslations[lang] = {};
      }
      newTranslations[lang][key] = value;
      return newTranslations;
    });
    setFeedbackMessage(null);
  };

  const handleResetKeyToDefault = (key: string) => {
    setEditedTranslations(prev => {
      const newTranslations = JSON.parse(JSON.stringify(prev));
      newTranslations.en[key] = defaultTranslations.en[key] || '';
      newTranslations.ne[key] = defaultTranslations.ne[key] || '';
      return newTranslations;
    });
    setFeedbackMessage({ type: 'success', message: `Key '${key}' reset to default.` });
  };

  const handleSaveAll = () => {
    onSaveTranslations(editedTranslations);
    setFeedbackMessage({ type: 'success', message: t('translationsSavedSuccess') });
  };

  const handleResetAll = () => {
    if (window.confirm(t('confirmResetAllTranslations'))) {
      onResetAllToDefaults();
      // The parent App.tsx will update currentCustomTranslations, which will flow down
      // and AdminTranslationsEditor will re-initialize with the new defaults via useEffect.
      setFeedbackMessage({ type: 'success', message: t('translationsResetSuccess') });
    }
  };

  const allKeys = useMemo(() => {
    const keys = new Set<string>();
    Object.keys(defaultTranslations.en).forEach(key => keys.add(key));
    Object.keys(defaultTranslations.ne).forEach(key => keys.add(key)); // Include keys that might only exist in default Nepali
    // Also include keys from current custom translations that might not be in defaults (e.g. if defaults changed)
    Object.keys(currentCustomTranslations.en).forEach(key => keys.add(key)); 
    Object.keys(currentCustomTranslations.ne).forEach(key => keys.add(key));
    return Array.from(keys).sort();
  }, [defaultTranslations, currentCustomTranslations]);

  const filteredKeys = useMemo(() => {
    if (!searchTerm) return allKeys;
    const lowerSearchTerm = searchTerm.toLowerCase();
    return allKeys.filter(key => 
      key.toLowerCase().includes(lowerSearchTerm) ||
      (editedTranslations.en[key] || defaultTranslations.en[key] || '').toLowerCase().includes(lowerSearchTerm) ||
      (editedTranslations.ne[key] || defaultTranslations.ne[key] || '').toLowerCase().includes(lowerSearchTerm)
    );
  }, [allKeys, searchTerm, editedTranslations, defaultTranslations]);

  return (
    <div className="animate-fadeIn p-4 sm:p-6 bg-background-light dark:bg-background-dark min-h-screen overflow-y-auto custom-scrollbar-hidden">
      <div className="mb-6 flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center px-3 py-2 text-sm bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 rounded-md text-textcol-light dark:text-textcol-dark"
        >
          <ArrowLeftIcon className="w-4 h-4 mr-2" />
          {t('backToCategories')} {/* Or a more generic "Back" */}
        </button>
        <h2 className="text-2xl sm:text-3xl font-bold text-primary-DEFAULT dark:text-primary-dark text-center flex-grow">
          {t('editUITextTitle')}
        </h2>
      </div>

      {feedbackMessage && (
        <div className={`p-3 mb-4 rounded-md text-sm ${feedbackMessage.type === 'success' ? 'bg-green-100 dark:bg-green-800 border border-green-300 dark:border-green-600 text-green-700 dark:text-green-200' : 'bg-red-100 dark:bg-red-800 border border-red-300 dark:border-red-600 text-red-700 dark:text-red-200'}`}>
          {feedbackMessage.message}
        </div>
      )}

      <div className="mb-6 sticky top-0 z-10 bg-background-light dark:bg-background-dark py-2">
        <div className="relative">
          <input
            type="text"
            placeholder={t('searchTranslationKeys')}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full p-3 pl-10 border border-bordercol-light dark:border-bordercol-dark rounded-md bg-card-light dark:bg-card-dark focus:ring-2 focus:ring-primary-DEFAULT dark:focus:ring-primary-dark text-textcol-light dark:text-textcol-dark"
          />
          <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 dark:text-gray-500" />
        </div>
      </div>
      
      <div className="space-y-6">
        {filteredKeys.length > 0 ? filteredKeys.map(key => (
          <div key={key} className="bg-card-light dark:bg-card-dark p-4 rounded-lg shadow-md">
            <h3 className="text-sm font-semibold text-gray-500 dark:text-gray-400 mb-1 break-all">{t('translationKey')}: <code className="bg-gray-100 dark:bg-gray-700 px-1 rounded text-primary-DEFAULT dark:text-primary-dark">{key}</code></h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-3">
              <div>
                <label htmlFor={`en-${key}`} className="block text-xs font-medium text-textcol-light dark:text-textcol-dark mb-1">{t('englishValue')}</label>
                <textarea
                  id={`en-${key}`}
                  value={editedTranslations.en[key] || ''}
                  onChange={(e) => handleInputChange('en', key, e.target.value)}
                  rows={2}
                  className="w-full p-2 border border-bordercol-light dark:border-bordercol-dark rounded-md bg-background-light dark:bg-gray-700 focus:ring-1 focus:ring-primary-DEFAULT dark:focus:ring-primary-dark text-sm"
                />
              </div>
              <div>
                <label htmlFor={`ne-${key}`} className="block text-xs font-medium text-textcol-light dark:text-textcol-dark mb-1">{t('nepaliValue')}</label>
                <textarea
                  id={`ne-${key}`}
                  value={editedTranslations.ne[key] || ''}
                  onChange={(e) => handleInputChange('ne', key, e.target.value)}
                  rows={2}
                  className="w-full p-2 border border-bordercol-light dark:border-bordercol-dark rounded-md bg-background-light dark:bg-gray-700 focus:ring-1 focus:ring-primary-DEFAULT dark:focus:ring-primary-dark text-sm"
                />
              </div>
            </div>
            <button
              onClick={() => handleResetKeyToDefault(key)}
              className="px-3 py-1 text-xs bg-yellow-500 hover:bg-yellow-600 text-white rounded-md"
            >
              {t('resetToDefault')}
            </button>
          </div>
        )) : (
           <p className="text-center text-gray-500 dark:text-gray-400 py-8">{t('noKeysFound')}</p>
        )}
      </div>

      <div className="mt-8 py-4 border-t border-bordercol-light dark:border-bordercol-dark flex flex-col sm:flex-row justify-end space-y-3 sm:space-y-0 sm:space-x-3 sticky bottom-0 bg-background-light dark:bg-background-dark z-10 p-4">
        <button
          onClick={handleResetAll}
          className="px-6 py-2.5 border border-red-500 text-red-500 hover:bg-red-50 dark:hover:bg-red-900 rounded-md transition-colors font-medium"
        >
          {t('resetAllTranslations')}
        </button>
        <button
          onClick={handleSaveAll}
          className="px-6 py-2.5 bg-primary-DEFAULT hover:bg-primary-hover dark:bg-primary-dark dark:hover:bg-primary-darkhover text-white rounded-md transition-colors font-medium"
        >
          {t('saveAllTranslations')}
        </button>
      </div>
    </div>
  );
};

export default AdminTranslationsEditor;
