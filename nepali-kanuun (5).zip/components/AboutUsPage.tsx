
import React from 'react';
import { CloseIcon, linkifyContent } from '../constants'; // Import linkifyContent

interface AboutUsPageProps {
  content: string;
  t: (key: string) => string;
  onClose: () => void;
}

const AboutUsPage: React.FC<AboutUsPageProps> = ({ content, t, onClose }) => {
  
  const processedContent = content
    .split('\n')
    .map(line => `<p>${linkifyContent(line)}</p>`) // Linkify each line and wrap in a paragraph
    .join(''); // Join paragraphs directly

  return (
    <div className="bg-card-light dark:bg-card-dark p-6 sm:p-8 rounded-lg shadow-xl my-6 mx-auto w-full max-w-3xl animate-fadeIn">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-3xl font-bold text-primary-DEFAULT dark:text-primary-dark">{t('aboutUs')}</h2>
        <button
          onClick={onClose}
          className="p-2 rounded-full text-gray-500 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700"
          aria-label={t('closeAboutUsPage')}
        >
          <CloseIcon className="w-6 h-6" />
        </button>
      </div>
      
      <div 
        className="prose dark:prose-invert max-w-none text-textcol-light dark:text-textcol-dark leading-relaxed"
        dangerouslySetInnerHTML={{ __html: processedContent }}
      />

      <button
        onClick={onClose}
        className="mt-8 px-4 py-2 bg-primary-DEFAULT hover:bg-primary-hover dark:bg-primary-dark dark:hover:bg-primary-darkhover text-white rounded-md transition-colors"
      >
        {t('backToNotes')}
      </button>
    </div>
  );
};

export default AboutUsPage;
