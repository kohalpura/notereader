
import React from 'react';
import { ChevronDownIcon, getLocalizedText } from '../constants';
import { Category, Language, LocalizedString } from '../types'; // Assuming Category might be imported if its structure is needed, or just {id: string, name: LocalizedString}

interface FilterControlsProps {
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  selectedCategory: string; // Stores category ID
  setSelectedCategory: (categoryId: string) => void;
  categories: Array<{id: string, name: LocalizedString}>; // Expecting array of category objects with localized names
  showBookmarksOnly: boolean;
  setShowBookmarksOnly: (show: boolean) => void;
  t: (key: string) => string; 
  currentLanguage: Language;
}

const FilterControls: React.FC<FilterControlsProps> = ({
  searchTerm,
  setSearchTerm,
  selectedCategory,
  setSelectedCategory,
  categories,
  showBookmarksOnly,
  setShowBookmarksOnly,
  t,
  currentLanguage
}) => {
  return (
    <div className="my-6 p-4 bg-card-light dark:bg-card-dark rounded-lg shadow">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
        <div className="md:col-span-1">
          <label htmlFor="search" className="block text-sm font-medium text-textcol-light dark:text-textcol-dark mb-1">
            {t('searchNotesLabel')}
          </label>
          <input
            type="text"
            id="search"
            placeholder={t('searchPlaceholder')}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full p-2 border border-bordercol-light dark:border-bordercol-dark rounded-md bg-background-light dark:bg-gray-700 focus:ring-2 focus:ring-primary-DEFAULT dark:focus:ring-primary-dark"
          />
        </div>

        <div className="md:col-span-1">
          <label htmlFor="category-filter" className="block text-sm font-medium text-textcol-light dark:text-textcol-dark mb-1">
            {t('filterByCategoryLabel')}
          </label>
          <div className="relative">
            <select
              id="category-filter"
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="appearance-none w-full p-2 pr-8 border border-bordercol-light dark:border-bordercol-dark rounded-md bg-background-light dark:bg-gray-700 focus:ring-2 focus:ring-primary-DEFAULT dark:focus:ring-primary-dark"
            >
              <option value="">{t('allCategoriesOption')}</option>
              {categories.map(cat => (
                <option key={cat.id} value={cat.id}>{getLocalizedText(cat.name, currentLanguage)}</option>
              ))}
            </select>
            <ChevronDownIcon className="absolute right-2 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500 dark:text-gray-400 pointer-events-none" />
          </div>
        </div>
        
        <div className="md:col-span-1 flex items-center justify-start md:justify-end h-full pt-6 md:pt-0">
            <label htmlFor="bookmark-filter" className="flex items-center cursor-pointer select-none">
                <input
                type="checkbox"
                id="bookmark-filter"
                checked={showBookmarksOnly}
                onChange={(e) => setShowBookmarksOnly(e.target.checked)}
                className="form-checkbox h-5 w-5 text-primary-DEFAULT dark:text-primary-dark rounded border-gray-300 dark:border-gray-600 focus:ring-primary-DEFAULT dark:focus:ring-primary-dark bg-background-light dark:bg-gray-700"
                />
                <span className="ml-2 text-sm text-textcol-light dark:text-textcol-dark">{t('showBookmarksOnlyLabel')}</span>
            </label>
        </div>

      </div>
    </div>
  );
};

export default FilterControls;