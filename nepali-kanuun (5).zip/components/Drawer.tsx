
import React from 'react';
import { UserRole, Theme, TextSize, TEXT_SIZE_MAP, FONT_SIZE_SLIDER_VALUES, TEXT_SIZE_LABELS } from '../types';
import { CloseIcon, UserIcon, LogoutIcon, AccessibilityIcon, SunIcon, MoonIcon, InfoIcon, EditIcon, SettingsIcon, BookOpenIcon, CollectionIcon } from '../constants';

interface DrawerProps {
  isOpen: boolean;
  onClose: () => void;
  userRole: UserRole;
  onAdminLoginClick: () => void;
  onLogoutClick: () => void;
  theme: Theme;
  setTheme: (theme: Theme) => void;
  textSizeValue: string; // string '0'-'4'
  setTextSizeValue: (value: string) => void;
  isReadingModeEnabled: boolean;
  setReadingModeEnabled: (enabled: boolean) => void;
  onAboutUsClick: () => void;
  onEditAboutUsClick: () => void;
  onAdminSettingsClick: () => void; 
  onEditTextClick: () => void;
  onManageFooterSectionsClick: () => void; // New prop for managing footer sections
  t: (key: string) => string;
}

const Drawer: React.FC<DrawerProps> = ({
  isOpen,
  onClose,
  userRole,
  onAdminLoginClick,
  onLogoutClick,
  theme,
  setTheme,
  textSizeValue,
  setTextSizeValue,
  isReadingModeEnabled,
  setReadingModeEnabled,
  onAboutUsClick,
  onEditAboutUsClick,
  onAdminSettingsClick,
  onEditTextClick,
  onManageFooterSectionsClick, // New prop
  t,
}) => {
  const toggleTheme = () => {
    setTheme(theme === Theme.LIGHT ? Theme.DARK : Theme.LIGHT);
  };

  const toggleReadingMode = () => {
    setReadingModeEnabled(!isReadingModeEnabled);
  };

  const currentTextSizeLabel = TEXT_SIZE_LABELS[TEXT_SIZE_MAP[textSizeValue] || TextSize.MEDIUM];

  const readingModeButtonBaseClasses = "w-full flex items-center space-x-3 px-3 py-2.5 text-left rounded-md transition-colors";
  const readingModeActiveClasses = "bg-emerald-100 dark:bg-emerald-600 border border-emerald-500 dark:border-emerald-400 text-emerald-700 dark:text-emerald-100 hover:bg-emerald-200 dark:hover:bg-emerald-500";
  const readingModeInactiveClasses = "text-textcol-light dark:text-textcol-dark hover:bg-gray-100 dark:hover:bg-gray-700";


  return (
    <>
      {/* Overlay */}
      <div
        className={`fixed inset-0 bg-black bg-opacity-50 z-[70] drawer-overlay ${isOpen ? 'opacity-100 visible' : 'opacity-0 invisible'}`}
        onClick={onClose}
        aria-hidden="true"
      ></div>

      {/* Drawer Panel */}
      <div
        className={`fixed top-0 left-0 h-full w-72 sm:w-80 bg-card-light dark:bg-card-dark shadow-xl z-[80] p-6 transform drawer ${isOpen ? 'drawer-open' : 'drawer-closed'} flex flex-col`}
        role="dialog"
        aria-modal="true"
        aria-labelledby="drawer-title"
      >
        <div className="flex items-center justify-between mb-6">
          <h2 id="drawer-title" className="text-xl font-semibold text-primary-DEFAULT dark:text-primary-dark">
            {t('noteReaderPro')}
          </h2>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700"
            aria-label={t('closeDrawer')}
          >
            <CloseIcon className="w-6 h-6" />
          </button>
        </div>

        <nav className="flex-grow space-y-3 overflow-y-auto custom-scrollbar-hidden">
          {userRole === UserRole.ADMIN ? (
            <button
              onClick={onLogoutClick}
              className="w-full flex items-center space-x-3 px-3 py-2.5 text-left text-textcol-light dark:text-textcol-dark hover:bg-gray-100 dark:hover:bg-gray-700 rounded-md transition-colors"
            >
              <LogoutIcon className="w-5 h-5 text-red-500 dark:text-red-400" />
              <span>{t('logout')}</span>
            </button>
          ) : (
            <button
              onClick={onAdminLoginClick}
              className="w-full flex items-center space-x-3 px-3 py-2.5 text-left text-textcol-light dark:text-textcol-dark hover:bg-gray-100 dark:hover:bg-gray-700 rounded-md transition-colors"
            >
              <UserIcon className="w-5 h-5" />
              <span>{t('adminLogin')}</span>
            </button>
          )}

          <div className="border-t border-bordercol-light dark:border-bordercol-dark my-3"></div>
          
          {userRole === UserRole.ADMIN && (
            <>
            <button
              onClick={onAdminSettingsClick}
              className="w-full flex items-center space-x-3 px-3 py-2.5 text-left text-textcol-light dark:text-textcol-dark hover:bg-gray-100 dark:hover:bg-gray-700 rounded-md transition-colors"
            >
              <SettingsIcon className="w-5 h-5" />
              <span>{t('adminSettings')}</span>
            </button>
             <button 
              onClick={onEditTextClick}
              className="w-full flex items-center space-x-3 px-3 py-2.5 text-left text-textcol-light dark:text-textcol-dark hover:bg-gray-100 dark:hover:bg-gray-700 rounded-md transition-colors"
            >
              <EditIcon className="w-5 h-5" /> 
              <span>{t('drawerEditText')}</span>
            </button>
             <button // Manage Footer Sections button
              onClick={onManageFooterSectionsClick}
              className="w-full flex items-center space-x-3 px-3 py-2.5 text-left text-textcol-light dark:text-textcol-dark hover:bg-gray-100 dark:hover:bg-gray-700 rounded-md transition-colors"
            >
              <CollectionIcon className="w-5 h-5" /> 
              <span>{t('drawerManageFooter')}</span>
            </button>
            <div className="border-t border-bordercol-light dark:border-bordercol-dark my-3"></div>
            </>
          )}


          {/* Accessibility Options */}
          <div className="space-y-1">
            <h3 className="px-3 text-sm font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">{t('accessibilityOptions')}</h3>
            <div className="px-3 py-2.5">
              <label htmlFor="font-size-slider" className="block text-sm font-medium text-textcol-light dark:text-textcol-dark mb-1">
                {t('fontSize')}: <span className="font-normal">{currentTextSizeLabel}</span>
              </label>
              <input
                type="range"
                id="font-size-slider"
                min="0"
                max={FONT_SIZE_SLIDER_VALUES.toString()}
                value={textSizeValue}
                onChange={(e) => setTextSizeValue(e.target.value)}
                className="w-full h-2 bg-gray-200 dark:bg-gray-600 rounded-lg appearance-none cursor-pointer"
                aria-label={t('fontSize')}
              />
            </div>
             <button
              onClick={toggleReadingMode}
              className={`${readingModeButtonBaseClasses} ${isReadingModeEnabled ? readingModeActiveClasses : readingModeInactiveClasses}`}
              aria-pressed={isReadingModeEnabled}
              aria-label={isReadingModeEnabled ? t('disableReadingMode') : t('enableReadingMode')}
            >
              <BookOpenIcon className="w-5 h-5" /> {/* Icon color will be inherited */}
              <span>{t('readingMode')}</span>
              <div className={`ml-auto w-10 h-5 flex items-center rounded-full p-0.5 cursor-pointer ${isReadingModeEnabled ? 'bg-[#588cff]' : 'bg-gray-300 dark:bg-gray-600'}`}>
                <div className={`bg-white w-4 h-4 rounded-full shadow-md transform duration-300 ease-in-out ${isReadingModeEnabled ? 'translate-x-5' : ''}`}></div>
              </div>
            </button>
          </div>
          
          {/* Theme Options */}
          <div className="space-y-1">
            <h3 className="px-3 text-sm font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">{t('themeOptions')}</h3>
            <button
              onClick={toggleTheme}
              className="w-full flex items-center space-x-3 px-3 py-2.5 text-left text-textcol-light dark:text-textcol-dark hover:bg-gray-100 dark:hover:bg-gray-700 rounded-md transition-colors"
              aria-label={theme === Theme.LIGHT ? t('darkTheme') : t('lightTheme')}
            >
              {theme === Theme.LIGHT ? <MoonIcon className="w-5 h-5" /> : <SunIcon className="w-5 h-5 text-yellow-400" />}
              <span>{theme === Theme.LIGHT ? t('darkTheme') : t('lightTheme')}</span>
            </button>
          </div>

           <div className="border-t border-bordercol-light dark:border-bordercol-dark my-3"></div>
          
          <button
            onClick={onAboutUsClick}
            className="w-full flex items-center space-x-3 px-3 py-2.5 text-left text-textcol-light dark:text-textcol-dark hover:bg-gray-100 dark:hover:bg-gray-700 rounded-md transition-colors"
          >
            <InfoIcon className="w-5 h-5" />
            <span>{t('aboutUs')}</span>
          </button>

          {userRole === UserRole.ADMIN && (
             <button
              onClick={onEditAboutUsClick}
              className="w-full flex items-center space-x-3 px-3 py-2.5 text-left text-textcol-light dark:text-textcol-dark hover:bg-gray-100 dark:hover:bg-gray-700 rounded-md transition-colors"
            >
              <EditIcon className="w-5 h-5" />
              <span>{t('editAboutUs')}</span>
            </button>
          )}

        </nav>
      </div>
    </>
  );
};

export default Drawer;
