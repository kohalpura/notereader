
import React, { useMemo, useEffect, useState } from 'react';
import { Note, TOCItem, Language, LocalizedString } from '../types';
import { CloseIcon, linkifyContent, getLocalizedText } from '../constants'; 

// Declare mammoth globally if not using modules for it
declare global {
  interface Window {
    mammoth?: any;
  }
}

interface NoteViewerProps {
  note: Note; 
  categoryDisplayName: string;
  onClose: () => void;
  t: (key: string, params?: Record<string, string | number>) => string;
  setActiveTocItems: (items: TOCItem[]) => void; 
  proseClass: string; 
  currentLanguage: Language;
}

const generateSlug = (text: string): string => {
  return text
    .toLowerCase()
    .replace(/\s+/g, '-') 
    .replace(/[^\w-]+/g, ''); 
};

const dataURLtoBlob = (dataurl: string): Blob | null => {
  const arr = dataurl.split(',');
  if (arr.length < 2) return null;
  const mimeMatch = arr[0].match(/:(.*?);/);
  if (!mimeMatch || mimeMatch.length < 2) return null;
  const mime = mimeMatch[1];
  let bstr;
  try {
    bstr = atob(arr[1]);
  } catch (e) {
    console.error("Failed to decode base64 string for PDF: ", e);
    return null;
  }
  let n = bstr.length;
  const u8arr = new Uint8Array(n);
  while (n--) {
    u8arr[n] = bstr.charCodeAt(n);
  }
  return new Blob([u8arr], { type: mime });
};


const NoteViewer: React.FC<NoteViewerProps> = ({ note, categoryDisplayName, onClose, t, setActiveTocItems, proseClass, currentLanguage }) => {
  const [displayablePdfUrl, setDisplayablePdfUrl] = useState<string | null>(null);

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString(undefined, { 
      year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' 
    });
  };

  const localizedTitle = getLocalizedText(note.title, currentLanguage);
  const localizedContentForProcessing = getLocalizedText(note.content, currentLanguage);

  useEffect(() => {
    let objectUrlInternal: string | null = null;

    if (note.pdfUrl) {
      if (note.pdfUrl.startsWith('data:')) { // Uploaded file
        const blob = dataURLtoBlob(note.pdfUrl);
        if (blob) {
          objectUrlInternal = URL.createObjectURL(blob);
          setDisplayablePdfUrl(objectUrlInternal);
        } else {
          setDisplayablePdfUrl(note.pdfUrl); // Fallback to direct data URL (might be blocked)
          console.warn("Failed to convert PDF data URL to Blob. Using direct data URL.");
        }
      } else if (note.pdfUrl.startsWith('http')) { // External URL
        setDisplayablePdfUrl(note.pdfUrl);
      } else {
        setDisplayablePdfUrl(null); // Invalid URL
      }
    } else {
      setDisplayablePdfUrl(null);
    }

    return () => {
      if (objectUrlInternal) {
        URL.revokeObjectURL(objectUrlInternal);
        // Ensure displayablePdfUrl is cleared if it was an object URL that's now revoked
        // This is important to prevent using a stale blob URL on next render
        setDisplayablePdfUrl(prevUrl => (prevUrl === objectUrlInternal ? null : prevUrl));
      }
    };
  }, [note.pdfUrl]);


  const htmlContent = useMemo(() => {
    const items: TOCItem[] = [];
    const headingRegex = /^(#{2,4})\s+(.*)/gm; 
    
    const contentWithHeadings = localizedContentForProcessing.replace(headingRegex, (fullMatch, hashes, headingText) => {
      const level = hashes.length; 
      const slug = generateSlug(headingText) + '-' + items.length; 
      if (!note.pdfUrl) { 
          items.push({ id: slug, level, text: headingText.trim() });
      }
      return `<h${level} id="${slug}" class="scroll-mt-24">${headingText.trim()}</h${level}>`; 
    });
    
    if (!note.pdfUrl) {
        setActiveTocItems(items);
    } else {
        setActiveTocItems([]); 
    }

    const finalHtml = contentWithHeadings
      .split('\n')
      .map(line => {
        const trimmedLine = line.trim();
        if (!trimmedLine) return ''; 

        if (trimmedLine.match(/^<h[2-4] id=".*" class="scroll-mt-24">.*<\/h[2-4]>$/i)) {
          return trimmedLine;
        }
        if (trimmedLine.startsWith('- ') || trimmedLine.startsWith('* ')) {
          const listItemContent = trimmedLine.substring(2);
          return `<li>${linkifyContent(listItemContent)}</li>`; 
        }
        return `<p>${linkifyContent(trimmedLine)}</p>`; 
      })
      .join(''); 

    return finalHtml;
  }, [localizedContentForProcessing, note.pdfUrl, setActiveTocItems, currentLanguage, t]);

  useEffect(() => {
    const mainContentArea = document.querySelector('main'); 
    if (mainContentArea) {
      mainContentArea.scrollTop = 0;
    }
    
    return () => {
      setActiveTocItems([]);
    };
  }, [note.id, setActiveTocItems]);


  return (
    <div className="bg-card-light dark:bg-card-dark p-6 sm:p-8 rounded-lg shadow-xl my-6 mx-auto w-full max-w-4xl animate-fadeIn relative">
      <div className="absolute top-4 right-4 z-10">
        <button
          onClick={onClose}
          className="p-2 rounded-full text-gray-500 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-primary-DEFAULT dark:focus:ring-primary-dark"
          aria-label={t('closeNoteViewer')}
        >
          <CloseIcon className="w-6 h-6" />
        </button>
      </div>
      
      <div className="mb-4 pr-10"> 
        <h1 className="text-3xl font-bold text-primary-DEFAULT dark:text-primary-dark break-words" id="note-title-main">
          {localizedTitle}
        </h1>
        {note.pdfFileName && (
          <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
            {t('documentLabel')}: {note.pdfFileName}
          </p>
        )}
      </div>

      <div className="text-sm text-gray-500 dark:text-gray-400 mb-4">
        <p>{t('categoryLabel')}: <span className="font-semibold">{categoryDisplayName}</span></p>
        <p>{t('lastUpdated')}: {formatDate(note.updatedAt)}</p>
        <p>{t('viewsLabel')}: {note.views || 0}</p>
      </div>

      {note.tags && note.tags.length > 0 && (
        <div className="mb-6">
          {note.tags.map(tag => (
            <span key={tag} className="inline-block bg-gray-200 dark:bg-gray-600 rounded-full px-3 py-1 text-sm font-semibold text-gray-700 dark:text-gray-200 mr-2 mb-2">
              #{tag}
            </span>
          ))}
        </div>
      )}

      {note.pdfUrl && (
        <div className="mb-6">
          <div className="mb-3 flex justify-end">
            <a
              href={note.pdfUrl} 
              download={note.pdfUrl.startsWith('data:') ? (note.pdfFileName || 'document.pdf') : undefined} // Only set download for data URLs
              className="px-4 py-2 bg-secondary-DEFAULT hover:bg-secondary-hover dark:bg-secondary-dark dark:hover:bg-secondary-darkhover text-white rounded-md transition-colors text-sm font-medium shadow-md"
              aria-label={`${t('downloadPdfButtonLabel')}: ${note.pdfFileName || localizedTitle}`}
              target="_blank" 
              rel="noopener noreferrer"
            >
              {t('downloadPdfButtonLabel')}
            </a>
          </div>
          {displayablePdfUrl ? (
            <iframe
              src={displayablePdfUrl}
              width="100%"
              className="border-none rounded-md shadow-inner bg-gray-100 dark:bg-gray-800"
              style={{ minHeight: '500px', height: '75vh' }}
              title={localizedTitle}
              aria-label={`${t('pdfPreviewLabel')} ${localizedTitle}`}
              // sandbox="allow-scripts allow-same-origin" // Consider for security with external URLs if needed
            >
              <p>{t('pdfNotSupported')}</p> 
            </iframe>
          ) : (
            <div className="w-100 flex justify-center items-center bg-gray-100 dark:bg-gray-800 rounded-md shadow-inner" style={{ minHeight: '500px', height: '75vh' }}>
                <p>{t('pdfNotSupported')}</p>
            </div>
          )}
           <p className="mt-2 text-xs text-gray-500 dark:text-gray-400 italic">
            {t('pdfBlockedMessage')}
          </p>
        </div>
      )}
      
      {localizedContentForProcessing.trim() && (
        <div 
          className={`prose dark:prose-invert max-w-none text-textcol-light dark:text-textcol-dark leading-relaxed text-justify ${proseClass} ${note.pdfUrl && localizedContentForProcessing.trim() ? 'mt-8 pt-6 border-t border-bordercol-light dark:border-bordercol-dark' : ''}`}
          dangerouslySetInnerHTML={{ __html: htmlContent }}
        />
      )}
      
      {!note.pdfUrl && !localizedContentForProcessing.trim() && (
        <p className="text-gray-500 dark:text-gray-400">{t('noContentAvailable')}</p>
      )}
      
      <button
        onClick={onClose}
        className="mt-8 px-4 py-2 bg-primary-DEFAULT hover:bg-primary-hover dark:bg-primary-dark dark:hover:bg-primary-darkhover text-white rounded-md transition-colors"
      >
        {t('backToNotes')}
      </button>
    </div>
  );
};

export default NoteViewer;
