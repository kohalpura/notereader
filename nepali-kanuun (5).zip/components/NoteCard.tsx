
import React from 'react';
import { Note, UserRole, Language, LocalizedString } from '../types';
import { EditIcon, DeleteIcon, BookmarkIcon, EyeIcon, getLocalizedText, PdfFileIcon } from '../constants';

interface NoteCardProps {
  note: Note;
  role: UserRole;
  categoryName: string; // Display resolved category name (already localized by App.tsx)
  onView?: (note: Note) => void;
  onEdit?: (note: Note) => void;
  onDelete?: (noteId: string) => void;
  onToggleBookmark?: (noteId: string) => void;
  t: (key: string) => string;
  currentLanguage: Language;
}

const NoteCard: React.FC<NoteCardProps> = ({ note, role, categoryName, onView, onEdit, onDelete, onToggleBookmark, t, currentLanguage }) => {
  const handleView = () => onView && onView(note);
  const handleEdit = (e: React.MouseEvent) => {
    e.stopPropagation(); 
    onEdit && onEdit(note);
  };
  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    onDelete && onDelete(note.id);
  };
  const handleToggleBookmark = (e: React.MouseEvent) => {
    e.stopPropagation();
    onToggleBookmark && onToggleBookmark(note.id);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
  };

  const localizedTitle = getLocalizedText(note.title, currentLanguage);
  const localizedContent = getLocalizedText(note.content, currentLanguage);
  
  let contentSnippet = '';
  if (note.pdfUrl && note.pdfFileName) {
    contentSnippet = `${t('pdfDocumentLabel')}: ${note.pdfFileName}`;
  } else {
    contentSnippet = localizedContent.split('\n')[0].substring(0, 150) + (localizedContent.length > 150 || localizedContent.includes('\n') ? '...' : '');
  }


  return (
    <div
      className="bg-card-light dark:bg-card-dark shadow-lg rounded-lg p-4 sm:p-6 hover:shadow-xl transition-shadow duration-300 cursor-pointer flex flex-col justify-between h-full"
      onClick={role === UserRole.READER ? handleView : undefined}
      role={role === UserRole.READER ? "button" : undefined}
      tabIndex={role === UserRole.READER ? 0 : undefined}
      onKeyDown={role === UserRole.READER ? (e) => (e.key === 'Enter' || e.key === ' ') && handleView() : undefined}
      aria-label={role === UserRole.READER ? `${t('viewNote')} ${localizedTitle}` : localizedTitle}
    >
      <div>
        <div className="flex items-center justify-between mb-2">
            <h3 className="text-xl font-semibold text-primary-DEFAULT dark:text-primary-dark truncate flex-grow" title={localizedTitle}>
                {localizedTitle}
            </h3>
            {note.pdfUrl && <PdfFileIcon className="w-5 h-5 text-red-500 dark:text-red-400 ml-2 flex-shrink-0" />}
        </div>
        <p className="text-gray-600 dark:text-gray-300 text-sm mb-1">{t('categoryLabel')}: {categoryName}</p>
        <p className="text-gray-500 dark:text-gray-400 text-xs mb-3">
          {t('lastUpdated')}: {formatDate(note.updatedAt)}
        </p>
        <p className="text-sm text-textcol-light dark:text-textcol-dark mb-4 line-clamp-3">
          {contentSnippet}
        </p>
        {note.tags && note.tags.length > 0 && (
          <div className="mb-3">
            {note.tags.map(tag => (
              <span key={tag} className="inline-block bg-gray-200 dark:bg-gray-600 rounded-full px-2 py-0.5 text-xs font-semibold text-gray-700 dark:text-gray-200 mr-1 mb-1">
                #{tag}
              </span>
            ))}
          </div>
        )}
      </div>

      <div className="flex items-center justify-between pt-3 border-t border-bordercol-light dark:border-bordercol-dark">
        <div className="flex items-center text-xs text-gray-500 dark:text-gray-400">
           <EyeIcon className="w-4 h-4 mr-1" /> {note.views || 0} {t('views')}
        </div>
        {role === UserRole.ADMIN && onEdit && onDelete && (
          <div className="flex space-x-2">
            <button
              onClick={handleEdit}
              className="p-2 text-blue-500 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300"
              aria-label={`${t('editNoteLabel')} ${localizedTitle}`}
            >
              <EditIcon />
            </button>
            <button
              onClick={handleDelete}
              className="p-2 text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300"
              aria-label={`${t('deleteNoteLabel')} ${localizedTitle}`}
            >
              <DeleteIcon />
            </button>
          </div>
        )}
        {role === UserRole.READER && onToggleBookmark && (
          <button
            onClick={handleToggleBookmark}
            className={`p-2 ${note.isBookmarked ? 'text-secondary-DEFAULT dark:text-secondary-dark' : 'text-gray-400 hover:text-gray-600 dark:hover:text-gray-300'}`}
            aria-label={note.isBookmarked ? `${t('removeBookmarkLabel')} ${localizedTitle}` : `${t('addBookmarkLabel')} ${localizedTitle}`}
          >
            <BookmarkIcon filled={note.isBookmarked} />
          </button>
        )}
      </div>
    </div>
  );
};

export default NoteCard;