
import React from 'react';
import { FooterSection, Language, LocalizedString } from '../types';
import { CloseIcon, getLocalizedText, linkifyContent } from '../constants';

interface FooterSectionViewerModalProps {
  section: FooterSection;
  onClose: () => void;
  t: (key: string) => string;
  currentLanguage: Language;
}

const FooterSectionViewerModal: React.FC<FooterSectionViewerModalProps> = ({ section, onClose, t, currentLanguage }) => {
  const title = getLocalizedText(section.title, currentLanguage);
  const content = section.content ? getLocalizedText(section.content, currentLanguage) : '';

  const processedContent = content
    .split('\n')
    .map(line => `<p>${linkifyContent(line)}</p>`)
    .join('');

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 z-[90] backdrop-blur-sm animate-fadeIn" role="dialog" aria-modal="true" aria-labelledby="footer-section-viewer-title">
      <div className="bg-card-light dark:bg-card-dark p-6 sm:p-8 rounded-lg shadow-2xl w-full max-w-2xl max-h-[80vh] flex flex-col">
        <div className="flex justify-between items-center mb-4 pb-4 border-b border-bordercol-light dark:border-bordercol-dark">
          <h2 id="footer-section-viewer-title" className="text-xl font-bold text-primary-DEFAULT dark:text-primary-dark">
            {title}
          </h2>
          <button
            onClick={onClose}
            className="p-1 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700"
            aria-label={t('close')}
          >
            <CloseIcon className="w-5 h-5 text-gray-600 dark:text-gray-300" />
          </button>
        </div>

        <div className="overflow-y-auto custom-scrollbar-hidden flex-grow mb-6">
          {processedContent ? (
            <div 
              className="prose dark:prose-invert max-w-none text-textcol-light dark:text-textcol-dark leading-relaxed"
              dangerouslySetInnerHTML={{ __html: processedContent }}
            />
          ) : (
            <p className="text-gray-500 dark:text-gray-400">{t('noContentAvailable')}</p>
          )}
        </div>

        <div className="text-right mt-auto">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-primary-DEFAULT hover:bg-primary-hover dark:bg-primary-dark dark:hover:bg-primary-darkhover text-white rounded-md transition-colors"
          >
            {t('close')}
          </button>
        </div>
      </div>
    </div>
  );
};

export default FooterSectionViewerModal;
