import React, { useState } from 'react';
import { Language, Theme } from '../types';
import { AppLogoIcon, MenuIcon, SearchIcon, LanguageIcon, CloseIcon } from '../constants';

interface HeaderProps {
  theme: Theme;
  toggleDrawer: () => void;
  currentLanguage: Language;
  setLanguage: (lang: Language) => void;
  onSearchToggle: (show: boolean) => void;
  isSearchVisible: boolean;
  onSearchSubmit: (term: string) => void;
  t: (key: string) => string; // Translation function
  appIconUrl?: string | null; // Optional app icon URL
}

const Header: React.FC<HeaderProps> = ({
  theme,
  toggleDrawer,
  currentLanguage,
  setLanguage,
  onSearchToggle,
  isSearchVisible,
  onSearchSubmit,
  t,
  appIconUrl,
}) => {
  const [headerSearchTerm, setHeaderSearchTerm] = useState('');

  const handleLanguageToggle = () => {
    setLanguage(currentLanguage === 'en' ? 'ne' : 'en');
  };

  const handleSearchIconClick = () => {
    if (isSearchVisible && headerSearchTerm) {
        onSearchSubmit(headerSearchTerm);
    } else if (isSearchVisible && !headerSearchTerm) {
        onSearchToggle(false); // Hide if it's visible and term is empty
    }
     else {
        onSearchToggle(true); // Show it
    }
  };
  
  const handleSearchInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setHeaderSearchTerm(e.target.value);
    if(!e.target.value && !isSearchVisible) { // If input cleared and search was not forced open
        onSearchToggle(false);
    }
  };

  const handleSearchFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearchSubmit(headerSearchTerm);
  };


  return (
    <header className="bg-card-light dark:bg-card-dark shadow-md p-3 sm:p-4 sticky top-0 z-50">
      <div className="container mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-2 sm:space-x-3">
          <button
            onClick={toggleDrawer}
            className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-primary-DEFAULT dark:focus:ring-primary-dark"
            aria-label={t('toggleDrawer')}
          >
            <MenuIcon className="w-6 h-6 text-gray-700 dark:text-gray-300" />
          </button>
          <AppLogoIcon src={appIconUrl} className="w-8 h-8 text-primary-DEFAULT dark:text-primary-dark" />
        </div>

        {isSearchVisible && (
            <form onSubmit={handleSearchFormSubmit} className="flex-grow max-w-xs sm:max-w-sm md:max-w-md lg:max-w-lg xl:max-w-xl mx-2 sm:mx-4">
                 <input
                    type="search"
                    placeholder={t('searchNotes')}
                    value={headerSearchTerm}
                    onChange={handleSearchInputChange}
                    className="w-full p-2 text-sm border border-bordercol-light dark:border-bordercol-dark rounded-md bg-background-light dark:bg-gray-700 focus:ring-2 focus:ring-primary-DEFAULT dark:focus:ring-primary-dark text-textcol-light dark:text-textcol-dark"
                    autoFocus
                />
            </form>
        )}

        <div className="flex items-center space-x-1 sm:space-x-2">
          <button
            onClick={handleSearchIconClick}
            className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-primary-DEFAULT dark:focus:ring-primary-dark"
            aria-label={isSearchVisible ? t('submitSearch') : t('openSearch')}
          >
            {isSearchVisible && headerSearchTerm ? <SearchIcon className="w-5 h-5 text-primary-DEFAULT dark:text-primary-dark" /> :
             isSearchVisible ? <CloseIcon className="w-5 h-5 text-gray-700 dark:text-gray-300" /> :
             <SearchIcon className="w-5 h-5 text-gray-700 dark:text-gray-300" />
            }
          </button>
          <button
            onClick={handleLanguageToggle}
            className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-primary-DEFAULT dark:focus:ring-primary-dark flex items-center"
            aria-label={t('toggleLanguage')}
          >
            <LanguageIcon className="w-5 h-5 text-gray-700 dark:text-gray-300" />
            <span className="ml-1 text-xs font-semibold text-gray-700 dark:text-gray-300">{currentLanguage.toUpperCase()}</span>
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;