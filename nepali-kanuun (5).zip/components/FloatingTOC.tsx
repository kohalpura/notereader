
import React from 'react';
import { TOCItem } from '../types';
import { TocListIcon, CloseIcon } from '../constants';

interface TableOfContentsProps {
  tocItems: TOCItem[];
  onItemClick: (id: string) => void;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  t: (key: string) => string;
}

const TableOfContents: React.FC<TableOfContentsProps> = ({ tocItems, onItemClick, isOpen, setIsOpen, t }) => {
  if (!tocItems || tocItems.length === 0) {
    return null;
  }

  const handleToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsOpen(!isOpen);
  };

  return (
    <div className="fixed top-20 right-4 sm:right-6 z-50">
      <button
        onClick={handleToggle}
        className="relative w-12 h-12 sm:w-14 sm:h-14 bg-card-light dark:bg-card-dark rounded-full shadow-lg flex items-center justify-center text-primary-DEFAULT dark:text-primary-dark hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors focus:outline-none focus:ring-2 focus:ring-primary-DEFAULT dark:focus:ring-primary-dark"
        aria-label={t('toggleTOC')}
        aria-expanded={isOpen}
        aria-controls="toc-panel-floating"
      >
        {isOpen ? <CloseIcon className="w-6 h-6 sm:w-7 sm:h-7" /> : <TocListIcon className="w-6 h-6 sm:w-7 sm:h-7" />}
        {/* Blinking Blue Dot */}
        {!isOpen && (
            <span className="absolute top-0.5 right-0.5 sm:top-1 sm:right-1 block h-3 w-3 sm:h-3.5 sm:w-3.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 sm:h-3.5 sm:w-3.5 bg-blue-500"></span>
            </span>
        )}
      </button>

      {isOpen && (
        <div
          id="toc-panel-floating"
          className="absolute top-full right-0 mt-2 w-64 sm:w-72 bg-card-light dark:bg-card-dark rounded-md shadow-xl border border-bordercol-light dark:border-bordercol-dark max-h-[calc(100vh-10rem)] overflow-y-auto custom-scrollbar-hidden py-2 z-40"
          onClick={(e) => e.stopPropagation()} // Prevent closing when clicking inside panel
        >
          <h3 className="text-sm font-semibold px-3 py-2 text-textcol-light dark:text-textcol-dark border-b border-bordercol-light dark:border-bordercol-dark">
            {t('tableOfContents')}
          </h3>
          <ul className="space-y-0.5 p-1">
            {tocItems.map(item => (
              <li key={item.id}>
                <button
                  onClick={() => onItemClick(item.id)}
                  className={`w-full text-left text-xs sm:text-sm py-1.5 px-2 rounded-md hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors
                              text-textcol-light dark:text-textcol-dark`}
                  style={{ paddingLeft: `${(item.level -1) * 0.75 + 0.5}rem`}} // Indentation
                >
                  <span className="truncate">{item.text}</span>
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default TableOfContents;
