
import React, { useState } from 'react';
import { CloseIcon, ADMIN_USERNAME } from '../constants'; // ADMIN_USERNAME is fixed

interface LoginModalProps {
  onClose: () => void;
  onLoginSuccess: () => void;
  adminPassword?: string; // Current admin password from App state
  t: (key: string) => string;
}

const LoginModal: React.FC<LoginModalProps> = ({ onClose, onLoginSuccess, adminPassword, t }) => {
  const [username, setUsername] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(''); 

    if (username === ADMIN_USERNAME && passwordInput === adminPassword) {
      onLoginSuccess();
    } else {
      setError(t('loginFailed'));
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 z-[90] backdrop-blur-sm animate-fadeIn" role="dialog" aria-modal="true" aria-labelledby="login-modal-title">
      <div className="bg-card-light dark:bg-card-dark p-6 sm:p-8 rounded-lg shadow-2xl w-full max-w-md overflow-y-auto custom-scrollbar-hidden max-h-[90vh]">
        <div className="flex justify-between items-center mb-6">
          <h2 id="login-modal-title" className="text-2xl font-bold text-primary-DEFAULT dark:text-primary-dark">{t('loginTitle')}</h2>
          <button
            onClick={onClose}
            className="p-1 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700"
            aria-label={t('closeLoginModal')}
          >
            <CloseIcon className="w-5 h-5 text-gray-600 dark:text-gray-300" />
          </button>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-100 dark:bg-red-900 border border-red-300 dark:border-red-700 text-red-700 dark:text-red-200 rounded-md text-sm">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="username" className="block text-sm font-medium text-textcol-light dark:text-textcol-dark mb-1">{t('usernameLabel')}</label>
            <input
              type="text"
              id="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full p-2.5 border border-bordercol-light dark:border-bordercol-dark rounded-md bg-background-light dark:bg-gray-700 focus:ring-2 focus:ring-primary-DEFAULT dark:focus:ring-primary-dark"
              required
              autoFocus
            />
          </div>
          <div>
            <label htmlFor="password" className="block text-sm font-medium text-textcol-light dark:text-textcol-dark mb-1">{t('passwordLabel')}</label>
            <input
              type="password"
              id="password"
              value={passwordInput}
              onChange={(e) => setPasswordInput(e.target.value)}
              className="w-full p-2.5 border border-bordercol-light dark:border-bordercol-dark rounded-md bg-background-light dark:bg-gray-700 focus:ring-2 focus:ring-primary-DEFAULT dark:focus:ring-primary-dark"
              required
            />
          </div>
          <button
            type="submit"
            className="block w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-textcol-light dark:text-textcol-dark hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors opacity-100 font-semibold text-base"
          >
            {t('loginButton')}
          </button>
        </form>
      </div>
    </div>
  );
};

export default LoginModal;
