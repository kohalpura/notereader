
import React, { useState, useEffect, useRef } from 'react';
import { Note, Category, LocalizedString, Language } from '../types';

interface NoteEditorProps {
  initialNote: Note | null; 
  onSave: (note: Note, newCategoryName?: LocalizedString) => void; // pdfData removed
  onCancel: () => void;
  categories: Category[];
  defaultCategoryId?: string;
  t: (key: string, params?: Record<string, string | number>) => string; 
  currentLanguage: Language;
}

const NoteEditor: React.FC<NoteEditorProps> = ({ initialNote, onSave, onCancel, categories, defaultCategoryId, t, currentLanguage }) => {
  const [titleEn, setTitleEn] = useState('');
  const [titleNe, setTitleNe] = useState('');
  const [contentEn, setContentEn] = useState('');
  const [contentNe, setContentNe] = useState('');
  const [selectedCategoryId, setSelectedCategoryId] = useState<string>('');
  const [customCategoryNameEn, setCustomCategoryNameEn] = useState('');
  const [customCategoryNameNe, setCustomCategoryNameNe] = useState('');
  const [tags, setTags] = useState(''); 
  
  // Master state for PDF data to be saved
  const [currentPdfUrl, setCurrentPdfUrl] = useState<string | undefined>(undefined);
  const [currentPdfFileName, setCurrentPdfFileName] = useState<string | undefined>(undefined);

  // Temporary state for URL input form
  const [pdfUrlInputForForm, setPdfUrlInputForForm] = useState('');
  const [pdfNameForUrlInputForForm, setPdfNameForUrlInputForForm] = useState('');
  
  const [hasChanges, setHasChanges] = useState(false);
  const pdfInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (initialNote) {
      setTitleEn(initialNote.title.en);
      setTitleNe(initialNote.title.ne || '');
      setContentEn(initialNote.content.en);
      setContentNe(initialNote.content.ne || '');
      setSelectedCategoryId(initialNote.category); 
      setCustomCategoryNameEn(''); 
      setCustomCategoryNameNe('');
      setTags(initialNote.tags.join(', '));
      
      setCurrentPdfUrl(initialNote.pdfUrl);
      setCurrentPdfFileName(initialNote.pdfFileName);

      if (initialNote.pdfUrl && initialNote.pdfUrl.startsWith('http')) {
        setPdfUrlInputForForm(initialNote.pdfUrl);
        setPdfNameForUrlInputForForm(initialNote.pdfFileName || '');
      } else {
        setPdfUrlInputForForm('');
        setPdfNameForUrlInputForForm('');
      }
      setHasChanges(false);
    } else {
      // New note
      setTitleEn('');
      setTitleNe('');
      setContentEn('');
      setContentNe('');
      setSelectedCategoryId(defaultCategoryId || (categories.length > 0 ? categories[0].id : ''));
      setCustomCategoryNameEn('');
      setCustomCategoryNameNe('');
      setTags('');
      setCurrentPdfUrl(undefined);
      setCurrentPdfFileName(undefined);
      setPdfUrlInputForForm('');
      setPdfNameForUrlInputForForm('');
      setHasChanges(false);
    }
  }, [initialNote, categories, defaultCategoryId]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!titleEn.trim()) {
        alert(t('titleEnEmptyAlert')); 
        return;
    }
    
    if (initialNote && !hasChanges) {
        return; 
    }

    let finalCategoryId = selectedCategoryId;
    let newCategoryLocalizedName: LocalizedString | undefined = undefined;

    if (selectedCategoryId === '_new_') {
        if (!customCategoryNameEn.trim()) {
            alert(t('categoryNameEmptyAlert'));
            return;
        }
        newCategoryLocalizedName = { 
            en: customCategoryNameEn.trim(), 
            ne: customCategoryNameNe.trim() || undefined
        };
        finalCategoryId = generateIdFromName(newCategoryLocalizedName.en); 
    } else if (!finalCategoryId) {
         alert(t('categoryEmptyAlert'));
         return;
    }

    const newOrUpdatedNote: Note = {
      id: initialNote ? initialNote.id : Date.now().toString() + Math.random().toString(36).substring(2,9),
      title: { en: titleEn.trim(), ne: titleNe.trim() || undefined },
      content: { en: contentEn.trim(), ne: contentNe.trim() || undefined },
      category: finalCategoryId, 
      tags: tags.split(',').map(tag => tag.trim()).filter(tag => tag !== ''),
      createdAt: initialNote ? initialNote.createdAt : new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      isBookmarked: initialNote?.isBookmarked || false,
      views: initialNote?.views || 0,
      pdfUrl: currentPdfUrl, // Use master state
      pdfFileName: currentPdfFileName, // Use master state
    };
    
    onSave(newOrUpdatedNote, newCategoryLocalizedName);
  };
  
  const generateIdFromName = (name: string) => name.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');

  const makeChangeHandler = <T extends HTMLInputElement | HTMLTextAreaElement>(setter: (val: string) => void) => (e: React.ChangeEvent<T>) => {
    setter(e.target.value);
    setHasChanges(true);
  };

  const handleCategoryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const value = e.target.value;
    setSelectedCategoryId(value);
    if (value !== '_new_') {
      setCustomCategoryNameEn('');
      setCustomCategoryNameNe('');
    }
    setHasChanges(true);
  };
  
  const handlePdfFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 10 * 1024 * 1024) { // 10MB limit
        alert(t('pdfSizeLimitError'));
        if(pdfInputRef.current) pdfInputRef.current.value = "";
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setCurrentPdfUrl(reader.result as string); // Set master state
        setCurrentPdfFileName(file.name); // Set master state
        setPdfUrlInputForForm(''); // Clear URL form inputs
        setPdfNameForUrlInputForForm('');
        setHasChanges(true);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSetPdfFromUrl = () => {
    if (!pdfUrlInputForForm.trim().match(/^https?:\/\//i)) {
        alert(t('invalidPdfUrlAlert'));
        return;
    }
    setCurrentPdfUrl(pdfUrlInputForForm.trim()); // Set master state
    setCurrentPdfFileName(pdfNameForUrlInputForForm.trim() || pdfUrlInputForForm.trim().split('/').pop() || "External PDF"); // Set master state
    if(pdfInputRef.current) pdfInputRef.current.value = ""; // Clear file input
    setHasChanges(true);
  };

  const handleRemovePdf = () => {
    setCurrentPdfUrl(undefined);
    setCurrentPdfFileName(undefined);
    setPdfUrlInputForForm('');
    setPdfNameForUrlInputForForm('');
    if(pdfInputRef.current) pdfInputRef.current.value = "";
    setHasChanges(true);
  };

  const isCreatingNew = !initialNote;
  const showSubmitButton = isCreatingNew || (initialNote && hasChanges);
  const submitButtonText = initialNote ? t('saveChanges') : t('createNote');

  const cancelLikeButtonClasses = "px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-textcol-light dark:text-textcol-dark hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors";
  const primaryButtonClasses = "px-4 py-2 bg-primary-DEFAULT hover:bg-primary-hover dark:bg-primary-dark dark:hover:bg-primary-darkhover text-white rounded-md transition-colors";
  
  const submitButtonClasses = isCreatingNew ? cancelLikeButtonClasses : primaryButtonClasses;

  const getPdfSourceType = (): string => {
    if (!currentPdfUrl) return '';
    if (currentPdfUrl.startsWith('data:')) return t('pdfSourceIsUploaded');
    if (currentPdfUrl.startsWith('http')) return t('pdfSourceIsUrl');
    return '';
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-[60] backdrop-blur-sm">
      <form
        onSubmit={handleSubmit}
        className="bg-card-light dark:bg-card-dark p-6 sm:p-8 rounded-lg shadow-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto custom-scrollbar-hidden"
      >
        <h2 className="text-2xl font-bold mb-6 text-primary-DEFAULT dark:text-primary-dark">
          {initialNote ? t('editNote') : t('createNewNote')}
        </h2>
        
        {/* Title Inputs */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6">
            <div className="mb-4">
              <label htmlFor="titleEn" className="block text-sm font-medium text-textcol-light dark:text-textcol-dark mb-1">{t('titleEnLabel')}<span className="text-red-500">*</span></label>
              <input
                type="text"
                id="titleEn"
                value={titleEn}
                onChange={makeChangeHandler(setTitleEn)}
                className="w-full p-2 border border-bordercol-light dark:border-bordercol-dark rounded-md bg-background-light dark:bg-gray-700 focus:ring-2 focus:ring-primary-DEFAULT dark:focus:ring-primary-dark"
                required
              />
            </div>
            <div className="mb-4">
              <label htmlFor="titleNe" className="block text-sm font-medium text-textcol-light dark:text-textcol-dark mb-1">{t('titleNeLabel')}</label>
              <input
                type="text"
                id="titleNe"
                value={titleNe}
                onChange={makeChangeHandler(setTitleNe)}
                className="w-full p-2 border border-bordercol-light dark:border-bordercol-dark rounded-md bg-background-light dark:bg-gray-700 focus:ring-2 focus:ring-primary-DEFAULT dark:focus:ring-primary-dark"
              />
            </div>
        </div>

        {/* Content Inputs */}
        <div className="mb-4">
          <label htmlFor="contentEn" className="block text-sm font-medium text-textcol-light dark:text-textcol-dark mb-1">{t('contentEnLabel')}</label>
          <textarea
            id="contentEn"
            value={contentEn}
            onChange={makeChangeHandler(setContentEn)}
            rows={currentLanguage === 'en' ? 6 : 4}
            className="w-full p-2 border border-bordercol-light dark:border-bordercol-dark rounded-md bg-background-light dark:bg-gray-700 focus:ring-2 focus:ring-primary-DEFAULT dark:focus:ring-primary-dark"
            placeholder={t('contentPlaceholder')}
          />
        </div>
        <div className="mb-4">
          <label htmlFor="contentNe" className="block text-sm font-medium text-textcol-light dark:text-textcol-dark mb-1">{t('contentNeLabel')}</label>
          <textarea
            id="contentNe"
            value={contentNe}
            onChange={makeChangeHandler(setContentNe)}
            rows={currentLanguage === 'ne' ? 6 : 4}
            className="w-full p-2 border border-bordercol-light dark:border-bordercol-dark rounded-md bg-background-light dark:bg-gray-700 focus:ring-2 focus:ring-primary-DEFAULT dark:focus:ring-primary-dark"
            placeholder={t('contentPlaceholder')}
          />
        </div>
        
        {/* PDF Section */}
        <div className="mb-6 p-4 border border-dashed border-bordercol-light dark:border-bordercol-dark rounded-md space-y-4">
          <h3 className="text-md font-semibold text-textcol-light dark:text-textcol-dark">{t('attachPdfLabel')}</h3>
          
          {currentPdfFileName && (
            <div className="bg-gray-100 dark:bg-gray-700 p-2 rounded-md">
              <span className="text-sm text-textcol-light dark:text-textcol-dark truncate" title={currentPdfFileName}>
                {t('pdfCurrentSourceLabel', {fileName: currentPdfFileName})}
                <span className="text-xs text-gray-500 dark:text-gray-400 ml-1">{getPdfSourceType()}</span>
              </span>
            </div>
          )}

          {/* Upload PDF File Section */}
          <div>
            <h4 className="text-sm font-medium text-textcol-light dark:text-textcol-dark mb-2">{t('pdfUploadSectionTitle')}</h4>
            <label htmlFor="pdf-upload" className="cursor-pointer inline-flex items-center px-3 py-1.5 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600">
              {currentPdfUrl && currentPdfUrl.startsWith('data:') ? t('replacePdfButton') : t('uploadPdfButton')}
            </label>
            <input
              id="pdf-upload"
              name="pdf-upload"
              type="file"
              accept=".pdf"
              className="sr-only"
              onChange={handlePdfFileChange}
              ref={pdfInputRef}
            />
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">{t('pdfMaxSizeNote')}</p>
          </div>

          {/* Divider */}
          <div className="flex items-center my-3">
            <hr className="flex-grow border-gray-300 dark:border-gray-600"/>
            <span className="mx-2 text-xs text-gray-500 dark:text-gray-400">OR</span>
            <hr className="flex-grow border-gray-300 dark:border-gray-600"/>
          </div>

          {/* Use PDF from URL Section */}
          <div>
            <h4 className="text-sm font-medium text-textcol-light dark:text-textcol-dark mb-2">{t('pdfUrlSectionTitle')}</h4>
            <div className="space-y-2">
              <div>
                <label htmlFor="pdfUrlInput" className="block text-xs font-medium text-textcol-light dark:text-textcol-dark mb-0.5">{t('pdfUrlInputLabel')}</label>
                <input
                  type="url"
                  id="pdfUrlInput"
                  value={pdfUrlInputForForm}
                  onChange={makeChangeHandler(setPdfUrlInputForForm)}
                  placeholder={t('pdfUrlPlaceholder')}
                  className="w-full p-1.5 border border-bordercol-light dark:border-bordercol-dark rounded-md bg-background-light dark:bg-gray-700 focus:ring-1 focus:ring-primary-DEFAULT dark:focus:ring-primary-dark text-sm"
                />
              </div>
              <div>
                <label htmlFor="pdfNameForUrlInput" className="block text-xs font-medium text-textcol-light dark:text-textcol-dark mb-0.5">{t('pdfDisplayNameInputLabel')}</label>
                <input
                  type="text"
                  id="pdfNameForUrlInput"
                  value={pdfNameForUrlInputForForm}
                  onChange={makeChangeHandler(setPdfNameForUrlInputForForm)}
                  placeholder={t('pdfNameForUrlPlaceholder')}
                  className="w-full p-1.5 border border-bordercol-light dark:border-bordercol-dark rounded-md bg-background-light dark:bg-gray-700 focus:ring-1 focus:ring-primary-DEFAULT dark:focus:ring-primary-dark text-sm"
                />
              </div>
              <button
                type="button"
                onClick={handleSetPdfFromUrl}
                className="px-3 py-1.5 text-sm bg-green-600 hover:bg-green-700 text-white rounded-md shadow-sm"
                disabled={!pdfUrlInputForForm.trim()}
              >
                {t('setPdfUrlButton')}
              </button>
            </div>
          </div>
          
          {currentPdfUrl && (
             <button 
                type="button" 
                onClick={handleRemovePdf} 
                className="mt-3 w-full px-3 py-1.5 text-xs bg-red-500 hover:bg-red-600 text-white rounded-md"
            >
                {t('removePdfButton')}
            </button>
          )}

        </div>


        {/* Category and Tags */}
        <div className="mb-4">
          <label htmlFor="category" className="block text-sm font-medium text-textcol-light dark:text-textcol-dark mb-1">{t('categoryLabel')}</label>
          <select
            id="category"
            value={selectedCategoryId}
            onChange={handleCategoryChange}
            className="w-full p-2 border border-bordercol-light dark:border-bordercol-dark rounded-md bg-background-light dark:bg-gray-700 focus:ring-2 focus:ring-primary-DEFAULT dark:focus:ring-primary-dark"
          >
            <option value="" disabled>{t('selectCategory')}</option>
            {categories.map(cat => <option key={cat.id} value={cat.id}>{cat.name.en}{cat.name.ne ? ` / ${cat.name.ne}` : ''}</option>)}
            <option value="_new_">{t('newCategoryOption')}</option>
          </select>
          {selectedCategoryId === '_new_' && (
            <div className="mt-2 grid grid-cols-1 md:grid-cols-2 gap-x-4">
                <input
                type="text"
                placeholder={`${t('newCategoryPlaceholder')} (${t('titleEnLabel').split('(')[1]}`}
                value={customCategoryNameEn}
                onChange={makeChangeHandler(setCustomCategoryNameEn)}
                className="w-full mt-2 p-2 border border-bordercol-light dark:border-bordercol-dark rounded-md bg-background-light dark:bg-gray-700 focus:ring-2 focus:ring-primary-DEFAULT dark:focus:ring-primary-dark"
                />
                <input
                type="text"
                placeholder={`${t('newCategoryPlaceholder')} (${t('titleNeLabel').split('(')[1]}`}
                value={customCategoryNameNe}
                onChange={makeChangeHandler(setCustomCategoryNameNe)}
                className="w-full mt-2 p-2 border border-bordercol-light dark:border-bordercol-dark rounded-md bg-background-light dark:bg-gray-700 focus:ring-2 focus:ring-primary-DEFAULT dark:focus:ring-primary-dark"
                />
            </div>
          )}
        </div>

        <div className="mb-6">
          <label htmlFor="tags" className="block text-sm font-medium text-textcol-light dark:text-textcol-dark mb-1">{t('tagsLabel')}</label>
          <input
            type="text"
            id="tags"
            value={tags}
            onChange={makeChangeHandler(setTags)}
            className="w-full p-2 border border-bordercol-light dark:border-bordercol-dark rounded-md bg-background-light dark:bg-gray-700 focus:ring-2 focus:ring-primary-DEFAULT dark:focus:ring-primary-dark"
            placeholder={t('tagsPlaceholder')}
          />
        </div>

        {/* Action Buttons */}
        <div className="flex justify-end space-x-3">
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-textcol-light dark:text-textcol-dark hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors"
          >
            {t('cancel')}
          </button>
          {showSubmitButton && (
            <button
              type="submit"
              className={submitButtonClasses}
            >
              {submitButtonText}
            </button>
          )}
        </div>
      </form>
    </div>
  );
};

export default NoteEditor;
