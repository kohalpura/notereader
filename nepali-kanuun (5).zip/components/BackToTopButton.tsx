
import React, { useState, useEffect } from 'react';
import { ChevronUpIcon } from '../constants';

interface BackToTopButtonProps {
  t: (key: string) => string;
}

const BackToTopButton: React.FC<BackToTopButtonProps> = ({ t }) => {
  const [isVisible, setIsVisible] = useState(false);

  const toggleVisibility = () => {
    if (window.pageYOffset > 300) {
      setIsVisible(true);
    } else {
      setIsVisible(false);
    }
  };

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    });
  };

  useEffect(() => {
    window.addEventListener('scroll', toggleVisibility);
    return () => {
      window.removeEventListener('scroll', toggleVisibility);
    };
  }, []);

  return (
    <>
      {isVisible && (
        <button
          onClick={scrollToTop}
          className="group fixed bottom-6 right-6 sm:bottom-8 sm:right-8 z-50 p-3 bg-primary-DEFAULT dark:bg-primary-dark rounded-full shadow-lg hover:bg-primary-hover dark:hover:bg-primary-darkhover focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-DEFAULT dark:focus:ring-offset-background-dark dark:focus:ring-primary-dark transition-all duration-300 ease-in-out opacity-100 hover:opacity-90"
          aria-label={t('scrollToTop')}
          title={t('scrollToTop')}
        >
          <ChevronUpIcon className="w-6 h-6 sm:w-7 sm:h-7 text-textcol-light group-hover:text-white dark:text-white" />
        </button>
      )}
    </>
  );
};

export default BackToTopButton;
