
export interface LocalizedString {
  en: string;
  ne?: string; // Nepali is optional, fallback to English if not provided
}

export interface Note {
  id: string;
  title: LocalizedString;
  content: LocalizedString; // For Markdown/text content
  category: string; // Should map to a Category.id
  tags: string[];
  createdAt: string; // ISO string
  updatedAt: string; // ISO string
  isBookmarked?: boolean;
  views?: number;
  pdfUrl?: string; // Optional: Data URL for an embedded PDF
  pdfFileName?: string; // Optional: Original name of the PDF file
}

export interface Category {
  id: string; // Unique identifier, e.g., a slugified name or a UUID
  name: LocalizedString;
  thumbnailUrl?: string; // Optional path for a thumbnail image/icon
  isDeletable?: boolean; // Defaults to true. 'Uncategorized' will be false.
}

export const UNCATEGORIZED_CATEGORY_ID = 'uncategorized';

export enum UserRole {
  READER = 'READER',
  ADMIN = 'ADMIN',
}

export enum Theme {
  LIGHT = 'light',
  DARK = 'dark',
}

export enum TextSize {
  XSMALL = 'text-xs',
  SMALL = 'text-sm',
  MEDIUM = 'text-base',
  LARGE = 'text-lg',
  XLARGE = 'text-xl',
}

// For slider mapping
export const TEXT_SIZE_MAP: Record<string, TextSize> = {
  '0': TextSize.XSMALL,
  '1': TextSize.SMALL,
  '2': TextSize.MEDIUM,
  '3': TextSize.LARGE,
  '4': TextSize.XLARGE,
};
export const TEXT_SIZE_LABELS: Record<TextSize, string> = {
  [TextSize.XSMALL]: 'X-Small',
  [TextSize.SMALL]: 'Small',
  [TextSize.MEDIUM]: 'Medium',
  [TextSize.LARGE]: 'Large',
  [TextSize.XLARGE]: 'X-Large',
};
export const FONT_SIZE_SLIDER_VALUES = Object.keys(TEXT_SIZE_MAP).length -1;

// For mapping TextSize to Tailwind Typography prose classes
export const PROSE_TEXT_SIZE_MAP: Record<TextSize, string> = {
  [TextSize.XSMALL]: 'prose-sm',
  [TextSize.SMALL]: 'prose-sm', // 'text-sm' can also map to prose-sm for a slightly larger base
  [TextSize.MEDIUM]: 'prose',    // 'prose' is equivalent to 'prose-base'
  [TextSize.LARGE]: 'prose-lg',
  [TextSize.XLARGE]: 'prose-xl',
};


export type Language = 'en' | 'ne';

export interface Translations {
  [key: string]: string;
}

export interface AllTranslations {
  en: Translations;
  ne: Translations;
}

export enum FooterSectionActionType {
  LINK = 'LINK',
  MODAL_CONTENT = 'MODAL_CONTENT',
}

export interface FooterSection {
  id: string;
  title: LocalizedString;
  actionType: FooterSectionActionType;
  link?: string; // Used if actionType is LINK
  linkIsPlayStore?: boolean; // Used if actionType is LINK and link is for Play Store
  content?: LocalizedString; // Used if actionType is MODAL_CONTENT
  order: number; // To determine display order
  isVisible: boolean; // To toggle visibility in the footer
}

export type View = 
  | 'NOTES_LIST' 
  | 'NOTE_VIEWER' 
  | 'ABOUT_US' 
  | 'ADMIN_EDIT_ABOUT'
  | 'ADMIN_CATEGORIES_VIEW' 
  | 'ADMIN_CATEGORY_NOTES_VIEW'
  | 'ADMIN_TRANSLATIONS_EDIT'
  | 'ADMIN_FOOTER_SECTIONS_VIEW' // New: Admin view for managing footer sections
  | 'ADMIN_SETTINGS'; 

export interface TOCItem {
  id: string; // HTML ID for scrolling
  level: number; // Heading level (1 for h1, 2 for h2, etc.)
  text: string; // Text content of the heading
}
